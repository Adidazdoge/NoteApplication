package interface_adapters.presenters;

import frameworks.view.SignUpView;

public class SignUp {
    private SignUpView signUpView;

    public SignUp(SignUpView signUpView) {
        this.signUpView = signUpView;
    }
}
