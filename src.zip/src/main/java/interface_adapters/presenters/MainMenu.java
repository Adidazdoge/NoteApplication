package interface_adapters.presenters;

import frameworks.view.MainView;

public class MainMenu {
    private MainView mainView;
    public MainMenu(MainView mainView){
        this.mainView = mainView;
    }
}
