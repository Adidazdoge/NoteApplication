package usecases.endprocesshorde;

/**
 * No need of inputdata as this is automatic move, this usecase is only called when day hits 60 and player clicked
 * next day.
 */
public class HordeInputData {
}
