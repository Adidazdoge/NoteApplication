package usecases.gamenewday;

/**
 * Input data from player ui side, which is nothing because we don't need anything to decide how everything is change
 * form outside.
 */
public class NewdayInputData {
}
