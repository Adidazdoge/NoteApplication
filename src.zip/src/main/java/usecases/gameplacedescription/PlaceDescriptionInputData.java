package usecases.gameplacedescription;

/**
 * We don't need anything from player's side, this is automatic move.
 */

public class PlaceDescriptionInputData {
}
