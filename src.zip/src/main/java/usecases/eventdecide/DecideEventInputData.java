package usecases.eventdecide;

/**
 * This input data is not necessary, we need nothing more than the fact that is after a new day.
 */
public class DecideEventInputData {
}
