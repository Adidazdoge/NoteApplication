package usecases.gameminimap;

/**
 * Since this is automatic move, no data from player's side is needed.
 */
public class MinimapInputData {
}
