package usecases.eventinitialize;

/**
 * Don't need any input data from player's side. this is automatic move.
 */
public class EventInitializeInputData {
}
